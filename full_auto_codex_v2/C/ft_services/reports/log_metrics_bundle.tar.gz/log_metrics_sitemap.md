# Metrics Sitemap

- Reports dir: `/home/roro/work/projects/All-42-subject/full_auto_codex_v2/C/ft_services/reports`
- Manifest: `/home/roro/work/projects/All-42-subject/full_auto_codex_v2/C/ft_services/reports/log_metrics_manifest.json`

| Artifact | Exists | Size | sha256 |
| --- | --- | --- | --- |
| [`log_metrics_anomalies.html`](log_metrics_anomalies.html) | True | 1.1 KB | cc8813567ebe… |
| [`log_metrics_anomalies.json`](log_metrics_anomalies.json) | True | 0.5 KB | de36bc20e397… |
| [`log_metrics_anomalies.md`](log_metrics_anomalies.md) | True | 0.4 KB | 1e471dbba299… |
| [`log_metrics_badge_history.csv`](log_metrics_badge_history.csv) | True | 8.8 KB | 32cc279a9dcb… |
| [`log_metrics_badge_history.html`](log_metrics_badge_history.html) | True | 7.8 KB | fb07f3894ed2… |
| [`log_metrics_badge_history.md`](log_metrics_badge_history.md) | True | 2.9 KB | fb2233f022d7… |
| [`log_metrics_badge.svg`](log_metrics_badge.svg) | True | 0.9 KB | 58f67ec42797… |
| [`log_metrics_bundle.tar.gz`](log_metrics_bundle.tar.gz) | True | 29.3 KB | eb1b0434dcf5… |
| [`log_metrics_checksums.txt`](log_metrics_checksums.txt) | True | 3.9 KB | - |
| `checksums_guard` | False | 0 KB | - |
| `compare_html` | False | 0 KB | - |
| [`log_metrics_compare.md`](log_metrics_compare.md) | True | 0.6 KB | 0116943cd5ee… |
| [`log_metrics_snapshot.status_top2.csv`](log_metrics_snapshot.status_top2.csv) | True | 0.2 KB | 5fdc009e3582… |
| [`log_metrics_guard_summary.csv`](log_metrics_guard_summary.csv) | True | 0.6 KB | 72e4bb702fea… |
| [`log_metrics_guard_summary.html`](log_metrics_guard_summary.html) | True | 2.6 KB | 9c313dc14697… |
| [`log_metrics_guard_summary.json`](log_metrics_guard_summary.json) | True | 2.2 KB | ee7e33c5aa4d… |
| [`log_metrics_guard_summary.md`](log_metrics_guard_summary.md) | True | 1.6 KB | f895c3c6adb7… |
| [`log_metrics_guard_summary.json`](log_metrics_guard_summary.json) | True | 2.2 KB | ee7e33c5aa4d… |
| [`log_metrics_history.csv`](log_metrics_history.csv) | True | 0.8 KB | 8e7267f3e528… |
| [`log_metrics_snapshot.status_top2.html`](log_metrics_snapshot.status_top2.html) | True | 1.1 KB | 1cd42398aa0e… |
| [`index.html`](index.html) | True | 9.8 KB | 6c7c6a1ec113… |
| [`index.md`](index.md) | True | 6.7 KB | 94276ee1453a… |
| [`log_metrics_snapshot.status_top2.json`](log_metrics_snapshot.status_top2.json) | True | 0.4 KB | 44b833f5d2c5… |
| [`log_metrics_snapshot.status_top2.jsonl`](log_metrics_snapshot.status_top2.jsonl) | True | 0.4 KB | 7cde037d56b1… |
| [`log_metrics_latest.html`](log_metrics_latest.html) | True | 7.4 KB | 9b8068c45495… |
| [`log_metrics_latest.json`](log_metrics_latest.json) | True | 6.5 KB | c822370d3248… |
| [`log_metrics_latest.md`](log_metrics_latest.md) | True | 4.5 KB | 78a2578912aa… |
| [`log_metrics_manifest.json`](log_metrics_manifest.json) | True | 8.7 KB | - |
| [`log_metrics_snapshot.status_top2.md`](log_metrics_snapshot.status_top2.md) | True | 0.5 KB | b3e3ae0c9edf… |
| [`log_metrics_overall_history.csv`](log_metrics_overall_history.csv) | True | 2.1 KB | d2e60192df9c… |
| [`log_metrics_overview.md`](log_metrics_overview.md) | True | 1.3 KB | 517da6676982… |
| [`log_metrics_overview.html`](log_metrics_overview.html) | True | 3.4 KB | 749772e97c84… |
| [`log_metrics_overview.md`](log_metrics_overview.md) | True | 1.3 KB | 517da6676982… |
| [`portal.html`](portal.html) | True | 72.5 KB | 1a1272259b6b… |
| [`log_metrics_run_summary.json`](log_metrics_run_summary.json) | True | 2.3 KB | 591fc330a460… |
| [`log_metrics_run_summary.html`](log_metrics_run_summary.html) | True | 3.0 KB | 7d5d716aa023… |
| [`log_metrics_run_summary.md`](log_metrics_run_summary.md) | True | 1.9 KB | 6be8964f04bc… |
| [`log_metrics_sitemap.md`](log_metrics_sitemap.md) | True | 4.8 KB | 38bfc781f643… |
| [`log_metrics_sitemap.html`](log_metrics_sitemap.html) | True | 7.2 KB | e1d6d4e52fe0… |
| [`log_metrics_sitemap.json`](log_metrics_sitemap.json) | True | 9.9 KB | 60077a20617d… |
| [`log_metrics_stats.html`](log_metrics_stats.html) | True | 0.9 KB | 3709ad9d19de… |
| [`log_metrics_stats.md`](log_metrics_stats.md) | True | 0.3 KB | d306980a76d7… |
| [`log_metrics_status_badge.svg`](log_metrics_status_badge.svg) | True | 1.0 KB | a7795bce30ec… |
| [`log_metrics_status.json`](log_metrics_status.json) | True | 1.1 KB | d654d2051263… |
| [`log_metrics_snapshot.status_top2.summary.md`](log_metrics_snapshot.status_top2.summary.md) | True | 0.3 KB | 0effa70b8279… |
| [`log_metrics_trend.html`](log_metrics_trend.html) | True | 2.6 KB | 22f4c20bd4f6… |
| [`log_metrics_trend.md`](log_metrics_trend.md) | True | 0.8 KB | bc0b4eeea099… |

## Totals
- Artifacts (required): 44
- Present: 44
- Missing: 0
- Total size: 228.4 KB
- Optional (ignored in counts): checksums_guard, compare_html, compare_md
