#ifndef EXECUTOR_H
# define EXECUTOR_H

# include "ast.h"
# include "minishell.h"

int	ms_execute(t_ms *ms, t_ast *ast);

#endif
